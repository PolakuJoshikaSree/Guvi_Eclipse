package com.flightapp.model.enums;

public enum BookingStatus {
    CONFIRMED,
    CANCELLED
}
