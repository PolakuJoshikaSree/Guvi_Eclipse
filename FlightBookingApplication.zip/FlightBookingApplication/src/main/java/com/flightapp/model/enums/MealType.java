package com.flightapp.model.enums;

public enum MealType {
    VEG, NON_VEG, NONE
}
