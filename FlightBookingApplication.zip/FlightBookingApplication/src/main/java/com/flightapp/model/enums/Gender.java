package com.flightapp.model.enums;

public enum Gender {
    MALE, FEMALE, OTHER
}
