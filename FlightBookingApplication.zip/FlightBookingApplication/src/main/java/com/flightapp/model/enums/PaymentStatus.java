package com.flightapp.model.enums;

public enum PaymentStatus {
    SUCCESS,
    FAILED
}
